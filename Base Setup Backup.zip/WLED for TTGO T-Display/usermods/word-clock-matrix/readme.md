## Word clock usermod

By @bwente

See https://www.hackster.io/bwente/word-clock-with-just-two-components-073834 for the hardware guide!
Includes a customizable feature to lower the brightness at night.
