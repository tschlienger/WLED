# Usermods API v2 example usermod

In this usermod file you can find the documentation on how to take advantage of the new version 2 usermods!

## Installation 

Copy `usermod_v2_example.h` to the wled00 directory.  
Uncomment the corresponding lines in `usermods_list.cpp` and compile!  
_(You shouldn't need to actually install this, it does nothing useful)_

